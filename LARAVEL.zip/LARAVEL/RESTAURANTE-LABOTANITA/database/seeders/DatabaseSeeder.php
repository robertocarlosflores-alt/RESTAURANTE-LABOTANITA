<?php

namespace Database\Seeders;

use App\Models\Producto;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

// ============================================================
// LARAVEL II — clase 12
// El SEEDER es la semilla: los datos de arranque de la tabla.
// La tabla nace vacía; esto la llena con "artisan db:seed".
// Son los MISMOS tres productos del arreglo de PHP de la clase 10...
// ...pero ahora viven en la base de datos, no en el código.
// ============================================================

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    public function run(): void
    {
        // Cada create() = una fila nueva en la tabla productos.
        Producto::create(['nombre' => 'Arroz',  'precio' => 8]);
        Producto::create(['nombre' => 'Azúcar', 'precio' => 6]);
        Producto::create(['nombre' => 'Fideo',  'precio' => 5]);
    }
}
