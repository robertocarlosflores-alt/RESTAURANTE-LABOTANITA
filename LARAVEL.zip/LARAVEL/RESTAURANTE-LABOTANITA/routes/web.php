<?php

use App\Models\Producto;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});


// ============================================================
// LARAVEL I — clase 11 (este bloque se LEE de arriba a abajo)
// Una RUTA es una promesa: "cuando pidan esta URL, respondé esto".
// ============================================================

// 1) La ruta mínima: devuelve texto directo. Sin archivos, sin nada.
Route::get('/hola', function () {
    return 'Hola, soy Laravel — y esta respuesta viajó por una ruta.';
});

// 2) Una ruta que devuelve una VISTA (un archivo Blade en resources/views).
//    El array de productos es EL MISMO de ayer en PHP puro...
Route::get('/inicio', function () {
    $productos = ['Arroz', 'Azúcar', 'Fideo'];
    return view('inicio', ['productos' => $productos]);   // ...y viaja a la vista.
});

// 3) Otra página que HEREDA el mismo layout: el header y el footer
//    se escribieron UNA sola vez, en layouts/base.blade.php.
Route::get('/contacto', function () {
    return view('contacto');
});


// ============================================================
// LARAVEL II — clase 12 (este bloque se LEE de arriba a abajo)
// Hasta hoy los productos eran un arreglo escrito a mano: se perdían al recargar.
// Desde hoy viven en la BASE DE DATOS. El modelo Producto es quien va a buscarlos.
// ============================================================

// 4) LEER: Producto::all() trae TODAS las filas de la tabla productos.
//    Es el SELECT * de siempre... pero no escribimos ni una línea de SQL.
Route::get('/productos', function () {
    $productos = Producto::all();
    return view('productos', ['productos' => $productos]);   // igual que en la clase 11: los datos viajan a la vista
});

// 5) MOSTRAR EL FORMULARIO: esta ruta solo pinta la página, no guarda nada.
//    Fijate que la URL es la misma de abajo, pero el método es GET (entrar a ver).
Route::get('/productos/nuevo', function () {
    return view('productos-nuevo');
});

// 6) GUARDAR: misma URL, pero método POST (mandar datos).
//    Laravel elige esta ruta y no la de arriba por el METHOD del formulario.
Route::post('/productos/nuevo', function () {
    // request()->input('nombre') = "traeme lo que venía en el campo name="nombre"".
    // Es el $_POST['nombre'] de la clase 10, con mejor nombre.
    Producto::create([
        'nombre' => request()->input('nombre'),
        'precio' => request()->input('precio'),
    ]);   // una línea = un INSERT

    // Guardado el dato, mandamos al usuario a la lista para que lo vea ahí.
    return redirect('/productos');
});
